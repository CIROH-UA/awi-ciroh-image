NGIAB NEWLINE FIXER

This utility will repair the NGIAB-CloudInfra repository if it is incorrectly pulled with CRLF line endings instead of LFs. 

This issue only applies on Windows. While it can usually be avoided with proper Git configuration, this utility offers a failsafe if something goes awry.

Note that even after running this utility, you will still need to use WSL to execute the NGIAB scripts.
____

INSTRUCTIONS

1. Double-click "ngiab-newline-fixer.bat".
2. Provide the path to the NGIAB-CloudInfra repository.

The script should take care of everything from there!
____

OTHER NOTES

dos2unix is provided as public domain software. Please see https://directory.fsf.org/wiki/Dos2unix for more information.

The contents of this archive are free software. No license or terms apply to their use.